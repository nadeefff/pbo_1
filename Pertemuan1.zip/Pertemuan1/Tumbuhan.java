/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pertemuan1;

/**
 *
 * @author Nidzzz
 */
public class Tumbuhan extends MakhlukHidup {
    private String warnaDaun;
    private String arahDaun;

    /**
     * @return the warnaDaun
     */
    public String getWarnaDaun() {
        return warnaDaun;
    }

    /**
     * @param warnaDaun the warnaDaun to set
     */
    public void setWarnaDaun(String warnaDaun) {
        this.warnaDaun = warnaDaun;
    }

    /**
     * @return the arahDaun
     */
    public String getArahDaun() {
        return arahDaun;
    }

    /**
     * @param arahDaun the arahDaun to set
     */
    public void setArahDaun(String arahDaun) {
        this.arahDaun = arahDaun;
    }
}
