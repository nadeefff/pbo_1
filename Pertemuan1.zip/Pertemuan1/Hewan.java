/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pertemuan1;

/**
 *
 * @author Nidzzz
 */
public class Hewan extends MakhlukHidup {

    private int jumlahKaki;
    private String berjalan;

    /**
     * @return the JumlahKaki
     */
    public int getJumlahKaki() {
        return jumlahKaki;
    }

    /**
     * @param JumlahKaki the JumlahKaki to set
     */
    public void setJumlahKaki(int JumlahKaki) {
        this.jumlahKaki = JumlahKaki;
    }

    /**
     * @return the berjalan
     */
    public String getBerjalan() {
        return berjalan;
    }

    /**
     * @param Berjalan the berjalan to set
     */
    public void setBerjalan(String Berjalan) {
        this.berjalan = Berjalan;
    }
}
