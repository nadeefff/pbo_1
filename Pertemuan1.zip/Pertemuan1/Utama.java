/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pertemuan1;

/**
 *
 * @author Nidzzz
 */
public class Utama {

    public static void main(String[] args) {
        Hewan sapi = new Hewan();
        System.out.println("Sapi adalah Hewan yang");
        sapi.bernafas();
        sapi.tumbuh();
        System.out.println("");
        Tumbuhan pepaya = new Tumbuhan();
        System.out.println("Pepaya adalah tumbuhan yang");
        pepaya.setWarnaDaun("Hijau");
        pepaya.setArahDaun("Barat");
        pepaya.bernafas();
        pepaya.tumbuh();
        System.out.println("Pepaya adalah pohon yang daunnya berwarna " + pepaya.getWarnaDaun() + ", dan arah daunnya saat sore adalah " + pepaya.getArahDaun());
    
        System.out.println("");
        Ikan koi = new Ikan();
        koi.bernafas();
        koi.tumbuh();
        koi.setJumlahKaki(2);
        System.out.println("Jumlah kaki koi "+ String.valueOf(koi.getJumlahKaki()));
        
    }
}
